library(testthat)
library(rimgtool)

test_check("rimgtool")
